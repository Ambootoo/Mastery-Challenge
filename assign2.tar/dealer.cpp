#include "./dealer.h"



/*********************************************************************
 ** Function: add_card 
 ** Description: adds a card to the dealers hand
 ** Parameters: deck address
 ** Pre-Conditions: deck has a hand
 ** Post-Conditions: deck has another card
 **********************************************************************/
void dealer::add_card(deck* d)
{
   d_hand.add_card(d);
}

/*********************************************************************
 ** Function: get_card_total 
 ** Description: returns the card total
 ** Parameters: none
 ** Pre-Conditions:
 ** Post-Conditions:
 **********************************************************************/
int dealer::get_card_total() const
{
   return d_hand.get_card_total();
}

/*********************************************************************
 ** Function: print_cards 
 ** Description: prints the dealers cards
 ** Parameters: none
 ** Pre-Conditions:
 ** Post-Conditions:
 **********************************************************************/
void dealer::print_cards() const
{
   d_hand.print_hand();
}

/*********************************************************************
 ** Function: print_second_card 
 ** Description: prints second card
 ** Parameters: none
 ** Pre-Conditions:
 ** Post-Conditions:
 **********************************************************************/
void dealer::print_second_card() const
{
   d_hand.dealer_print();
}

/*********************************************************************
 ** Function: get_ace_total 
 ** Description: gets total assuming the ace is 11
 ** Parameters: none
 ** Pre-Conditions:
 ** Post-Conditions:
 **********************************************************************/
int dealer::get_ace_total() const
{
   return d_hand.get_ace_total();
}

/*********************************************************************
 ** Function: set_first_cards 
 ** Description: sets the first two cards in the hand
 ** Parameters: none
 ** Pre-Conditions: dealer has a hand
 ** Post-Conditions:
 **********************************************************************/
void dealer::set_first_cards(deck* d)
{
   d_hand.set_first_cards(d);
}
