#include "./hand.h"

using namespace std;

/*********************************************************************
 ** Function: hand constructor 
 ** Description:sets up a hand with two cards
 ** Parameters: none
 ** Pre-Conditions: cards is a pointer
 ** Post-Conditions: cards points to an array
 **********************************************************************/
hand::hand()
{
   cards = NULL;    //point cards to NULL so i dont seg fault
   num_cards = 2;
}

/*********************************************************************
 ** Function: hand copy constructor 
 ** Description: copies another hand to the one being made
 ** Parameters: hand reference
 ** Pre-Conditions: hand being copied is filled
 ** Post-Conditions: hand being made is identical to the first by values
 **********************************************************************/
hand::hand(hand& other)
{
   cards = new card[other.num_cards];
   num_cards = other.num_cards;
   for(int i = 0; i < num_cards; i++)
      cards[i] = other.cards[i];
}

/*********************************************************************
 ** Function: hand operator overload
 ** Description: copies a hand thats already made into a hand that already made
 ** Parameters: hand reference
 ** Pre-Conditions: both hands are already made with info in them
 ** Post-Conditions: hand one is deep copied to the other hand
 **********************************************************************/
void hand::operator =(const hand& other)
{
   if(cards != NULL)
      delete [] cards;    //delete because this already exists
   cards = new card[other.num_cards];
   num_cards = other.num_cards;
   for(int i = 0; i < num_cards; i++)
      cards[i] = other.cards[i];
}


/*********************************************************************
 ** Function: set_first_cards
 ** Description: takes two cards from the deck and puts them into the hand
 ** Parameters: deck address, to lower the deck by one card
 ** Pre-Conditions: hand has been made
 ** Post-Conditions: hand array points to two cards
 **********************************************************************/
void hand::set_first_cards(deck* d)
{
   delete [] cards;  //delete whatever cards the hand has
   cards = new card[2];   //everyone starts with two cards
   num_cards = 2;
   cards[0] = (*d).take_card();   //takes two cards from the deck
   cards[1] = (*d).take_card();
}

/*********************************************************************
 ** Function: deconstructor
 ** Description: deletes cards
 ** Parameters: 
 ** Pre-Conditions: 
 ** Post-Conditions: 
 **********************************************************************/
hand::~hand()
{
   delete [] cards;  //free up the heap
}

/*********************************************************************
 ** Function: add_card
 ** Description: increases number of cards by one
 ** Parameters: deck address
 ** Pre-Conditions: deck exists
 ** Post-Conditions: cards array is one bigger with another card
 **********************************************************************/
void hand::add_card(deck* d)
{
   card temp[num_cards];
   for(int i = 0; i < num_cards; i++)   //copy cards over into a temporary holder
      temp[i] = cards[i];
   delete [] cards;    //delete the cards in there
   num_cards++;   //make room for the new card
   cards = new card[num_cards];
   for(int i = 0; i < num_cards-1; i++)     //copy all the old cards back in
      cards[i] = temp[i];
   cards[num_cards-1] = (*d).take_card();    //add the new card, taking one off the deck

}

/*********************************************************************
 ** Function: print hand
 ** Description: prints the hand
 ** Parameters: none
 ** Pre-Conditions: 
 ** Post-Conditions: hand is printed to the screen
 **********************************************************************/
void hand::print_hand() const
{
   for(int i = 0; i < num_cards; i++)
   {
      if(cards[i].val == 11)    //accounting for the special cards
	 cout << "Jack";
      else if(cards[i].val == 12)
	 cout << "Queen";
      else if(cards[i].val == 13)
	 cout << "King";
      else if(cards[i].val == 1)
	 cout << "Ace";
      else
	 cout << cards[i].val;
      cout << " of " << cards[i].suit << endl;
   }
}

/*********************************************************************
 ** Function: is_ace
 ** Description: tells if the hand has an ace or not
 ** Parameters: none
 ** Pre-Conditions: hand had a cards array
 ** Post-Conditions: return true or false
 **********************************************************************/
bool hand::is_ace() const
{
   for(int i = 0; i < num_cards; i++)
   {
      if(cards[i].val == 1)
	 return true;
   }
   return false;   //if there was an ace it wouldve returned true
}

/*********************************************************************
 ** Function: dealer_print
 ** Description: prints the dealers second card
 ** Parameters: none
 ** Pre-Conditions: 
 ** Post-Conditions: info printed to the screen
 **********************************************************************/
void hand::dealer_print() const
{
      if(cards[1].val == 11)
	 cout << "Jack";
      else if(cards[1].val == 12)
	 cout << "Queen";
      else if(cards[1].val == 13)
	 cout << "King";
      else if(cards[1].val == 1)
	 cout << "Ace";
      else
	 cout << cards[1].val;

}

/*********************************************************************
 ** Function: get_ace_total
 ** Description: gets the total assuming aces are 11
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: none
 **********************************************************************/
int hand::get_ace_total() const
{
   int count = 0;
   for(int i = 0; i < num_cards; i++)
   {
      if(cards[i].val == 1)   //aces are 11
	 count += 11;
      else if(cards[i].val > 9)
	 count += 10;
      else
	 count += cards[i].val;
   }
   return count;

}

/*********************************************************************
 ** Function: get_card_total
 ** Description: gets the card total assuming aces are one
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: none
 **********************************************************************/
int hand::get_card_total() const
{
   int count = 0;
   for(int i = 0; i < num_cards; i++)
   {
      if(cards[i].val > 9)
	 count += 10;
      else
	 count += cards[i].val;    //aces are 1
   }
   return count;
}

int hand::get_num_cards() const
{
   return num_cards;
}
