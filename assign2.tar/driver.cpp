#include "game.h"

/******************************************************
 * ** Program: blackjack
 * ** Author: Josh Diedrich
 * ** Date: 04/20/2016
 * ** Description: Blackjack
 * ** Input: Number of Players
 * ** Output: Blackjack
 * ******************************************************/


int main()
{
   srand(time(NULL));
   int num_players;
   cout << "Enter the number of players: ";
   cin >> num_players;
   game g(num_players);
   g.play();
}

