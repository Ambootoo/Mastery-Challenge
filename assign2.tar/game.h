#include "dealer.h"
#include "player.h"



class game
{
   private:
      deck d;
      player* players;
      dealer deal;
      int num_players;
   public:
      game(int);
      game(const game &);
      ~game();
      void print_dealer() const;
      void operator =(const game&);
      void get_bets();
      void play();
      void shuffle_deck() {d.shuffle();}
      int dealer_draw();
      int player_draw(int);
      void justice_bringer(int, int, int);
      void print_totals() const;
      void reset_hands();
};
