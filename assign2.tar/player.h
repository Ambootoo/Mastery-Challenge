#include "./hand.h"
#pragma once

class player
{
   private:
      hand p_hand;
      int playing_total;
      int bet;

   public:
      player();
      int get_card_total() const;
      int get_ace_total() const;
      bool is_ace() const;
      void set_first_cards(deck*);
      int get_playing_total() const;
      void add_bet();
      void add_blackjack();
      void take_bet();
      void set_bet();
      void add_card(deck*);
      void print_cards() const;
      int get_num_cards() const;

};

