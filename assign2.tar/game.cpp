#include "./game.h"


/*********************************************************************
 ** Function: constructor 
 ** Description: sets the number of players to the input, and makes the players array
 ** Parameters: num_players
 ** Pre-Conditions:
 ** Post-Conditions:
 **********************************************************************/
game::game(int nplayers)
{
   num_players = nplayers;
   players = new player[num_players];
   for(int i = 0; i < num_players; i++)
      players[i].set_first_cards(&d);   //give each player two cards
   deal.set_first_cards(&d);   //give dealer two cards
}

/*********************************************************************
 ** Function: deconstructor 
 ** Description: deletes player array
 ** Parameters: none
 ** Pre-Conditions: players points somewhere
 ** Post-Conditions: players are deleted
 **********************************************************************/
game::~game()
{
   delete [] players;   //clearing up the heap
}

/*********************************************************************
 ** Function: operator overload 
 ** Description: copies an old game to a new one
 ** Parameters: game reference
 ** Pre-Conditions: games are already made
 ** Post-Conditions: games are deep copies
 **********************************************************************/
void game::operator =(const game &other)
{
   if(players != NULL)
      delete [] players;    //delete players because it already has been made
   num_players = other.num_players;
   players = new player[num_players];
   for(int i = 0; i < num_players; i++)
      players[i] = other.players[i];
   deal = other.deal;
}

/*********************************************************************
 ** Function: copy constructor 
 ** Description: copies a made game to a new one
 ** Parameters: game reference
 ** Pre-Conditions: other game has been made already
 ** Post-Conditions: games are deep copies
 **********************************************************************/
game::game(const game& other)
{
   num_players = other.num_players;
   players = new player[num_players];
   for(int i = 0; i < num_players; i++)
      players[i] = other.players[i];
   deal = other.deal;
}

/*********************************************************************
 ** Function: get_bets 
 ** Description: sets the bets for all the players
 ** Parameters: none
 ** Pre-Conditions: players has been made
 ** Post-Conditions: all bets are set
 **********************************************************************/
void game::get_bets()
{
   for(int i = 0; i < num_players; i++)
   {
      cout << "Player " << i+1 << endl;  //i+1 to correspond correctly
      players[i].set_bet();
   }
}

/*********************************************************************
 ** Function: player_draw 
 ** Description: lets a player draw cards until they bust or decide to stop
 ** Parameters: player_number
 ** Pre-Conditions: players has been made
 ** Post-Conditions: player is done hitting
 **********************************************************************/
int game::player_draw(int player_number)
{
   int p_total;
   int choice;
   players[player_number].print_cards();
   while(players[player_number].get_card_total() < 21)
   {
      cout << "Would you like to hit (1), or stay (2): ";
      cin >> choice;
      if(choice == 2)
	 break;
      players[player_number].add_card(&d);
      cout << endl << "New cards:" << endl;
      players[player_number].print_cards();
      cout << endl << "Total: " << players[player_number].get_card_total() << endl;
      if(players[player_number].is_ace())
	 cout << " or " << players[player_number].get_card_total() + 10;
      cout << endl;
   }
   if(players[player_number].get_ace_total() > 21)   //if the ace total is over 21, use the ace as 1
      p_total = players[player_number].get_card_total();
   else
   {
      p_total = players[player_number].get_ace_total();   //otherwise use the ace total
   }
   return p_total;

}

/*********************************************************************
 ** Function: dealer_draw 
 ** Description: draws the dealers cards until they reach 17
 ** Parameters: none
 ** Pre-Conditions:
 ** Post-Conditions: dealer will be above 16
 **********************************************************************/
int game::dealer_draw()
{
   int d_total;
   while(deal.get_ace_total() < 17)   //while the ace being 11 is under 17
      deal.add_card(&d);

   if(deal.get_ace_total() > 21)    // if the ace being 11 busts, use the ace being one, until its over 16
   {
      while(deal.get_card_total() < 17)
	 deal.add_card(&d);
   }

   if(deal.get_ace_total() > 21)    //if the ace total is over 21, use the other total
      d_total = deal.get_card_total();

   else d_total = deal.get_ace_total();   //if the ace total is not over 21, use the ace total
   
   cout << "Dealers Cards: " << endl; deal.print_cards();
   cout << endl;

   cout << "Dealer Total: " << d_total << endl << endl;

   if(deal.get_card_total() > 21)
      cout << "Dealer Busted! " << endl << endl;

   return d_total;
}

/*********************************************************************
 ** Function: justice_bringer
 ** Description: takes or give players money
 ** Parameters: player number, dealer total, player total
 ** Pre-Conditions: player and dealer have drawn
 ** Post-Conditions: player will get money if they are due or lose money if they are due
 **********************************************************************/
void game::justice_bringer(int player, int d_total, int p_total)
{
   if(p_total == 21)   //if they got blackjack
   {
      cout << "Player " << player+1 << " got blackjack!" << endl << endl;
      players[player].add_blackjack();
   }
   else if((d_total > 21) && (p_total < 22))    //if the dealer busted and the player didnt
   {
      players[player].add_bet();
   }
   else if(p_total > 21)   //if the player busted
   {
      cout << "Player " << player+1 << " BUSTED" << endl << endl;
      players[player].take_bet();
   }
   else if(p_total > d_total)   //if the player nor dealer busted but the player beat the dealer
   {
      cout << "Player " << player+1 << " beat the dealer!" << endl << endl;
      players[player].add_bet();
   }
   else if(p_total < d_total)   //if above, but the dealer beat the player
   {
      cout << "Player " << player+1 << " lost to the dealer!" << endl << endl;
      players[player].take_bet();
   }
   else   //only other condition is the player tying the dealer
      cout << "Player " << player+1 << " tied the dealer!" << endl << endl;
}

void game::print_totals() const
{
   for(int i = 0; i < num_players; i++)
   {
      cout << "Player " << i+1 << " Total money: " << players[i].get_playing_total() << endl;
      cout << endl << endl << endl;
   }
}

/*********************************************************************
 ** Function: print_dealer
 ** Description: prints dealers face up card
 ** Parameters: none
 ** Pre-Conditions: dealer has card
 ** Post-Conditions: cards are printed to the screen
 **********************************************************************/
void game::print_dealer() const
{
   cout  << endl << "Dealers face-up card is: ";
   deal.print_second_card();
   cout << endl << endl;
}

/*********************************************************************
 ** Function: play 
 ** Description: calls the functions in order to make a game play until they dont want to play again
 ** Parameters: none
 ** Pre-Conditions: players are made with filled hands, as well as the dealer
 ** Post-Conditions: game is played
 **********************************************************************/
void game::play()
{
   int play_again = 1;
   int player_totals[num_players];  //keeps track of final player totals corresponding w/ player array
  while(play_again == 1)
  {
   get_bets();
   print_dealer();
   for(int i = 0; i < num_players; i++)
   {
      cout << "Player: " << i+1 << endl;   //i + 1 so it matches the correct index
      player_totals[i] = player_draw(i);
      cout << endl << endl;
   }
   int dealer_total = dealer_draw();
   for(int i = 0; i < num_players; i++)
      justice_bringer(i, dealer_total, player_totals[i]);
   print_totals();
   cout << "Deal again? (1): ";
   cin >> play_again;
   reset_hands();  //sets each players hand back to two cards
  }

}

void game::reset_hands()
{
   for(int i = 0; i < num_players; i++)
      players[i].set_first_cards(&d);
   deal.set_first_cards(&d);
}

