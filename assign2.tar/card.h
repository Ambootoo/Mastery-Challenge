#include <iostream>
#include <string>

using namespace std;


struct card
{
   int val;
   string suit;
};
