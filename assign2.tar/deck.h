#include <iostream>
#include <string>
#include <time.h>
#include <stdlib.h>
#include "card.h"

#pragma once

using namespace std;


class deck
{
   private:
      card* cards;
      int num_cards;
   public:
      ~deck();
      deck(deck &);
      deck();
      card take_card();
      card get_card(int);
      void set_num_cards(int);
      void shuffle();
      const int get_num_cards();
};


