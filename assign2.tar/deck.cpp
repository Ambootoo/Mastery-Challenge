#include "./deck.h"



/*********************************************************************
 ** Function: deck copy constructor
 ** Description: sets the contents of an old deck into a new one
 ** Parameters: deck reference
 ** Pre-Conditions: none
 ** Post-Conditions: deck is filled with the values of the old deck
 **********************************************************************/
deck::deck(deck & other)
{
   num_cards = 52;
   cards = new card[52];
   for(int i = 0; i < 52; i++)
   {
   cards[i] = other.cards[i];
   }
   cout << "h" << endl;
}

/*********************************************************************
 ** Function: deconstructor 
 ** Description: deletes card array
 ** Parameters: 
 ** Pre-Conditions: card array points somewhere
 ** Post-Conditions: 
 **********************************************************************/
deck::~deck()
{
   delete [] cards;
}


/*********************************************************************
 ** Function: shuffle 
 ** Description: shuffles the deck
 ** Parameters: none
 ** Pre-Conditions: card array exists
 ** Post-Conditions: card array gets randomized in order
 **********************************************************************/
void deck::shuffle()
{
   srand(time(NULL));
   int r1, r2;
   card temp;
   for(int i = 0; i < 150; i++)
   {
   
      r1 = rand() % 52;
      r2 = rand() % 52;
      temp = cards[r1];
      cards[r1] = cards[r2];
      cards[r2] = temp;
   }
}

/*********************************************************************
 ** Function: get_card
 ** Description: returns a card
 ** Parameters: number
 ** Pre-Conditions: none
 ** Post-Conditions: none
 **********************************************************************/
card deck::get_card(int num)
{
   return cards[num];
}

/*********************************************************************
 ** Function: deck constructor 
 ** Description: makes a card array of 52
 ** Parameters: none
 ** Pre-Conditions: cards is a pointer to card struct
 ** Post-Conditions: cards is pointing to an array of 52 cards
 **********************************************************************/
deck::deck()
{
   cards = new card[52];
   num_cards = 52;
   for(int i = 1; i < 14; i++) //clubs
   {
      cards[i-1].val = i;
      cards[i-1].suit = "clubs";
   }
   for(int i = 14; i < 27; i++) //diamonds
   {
      cards[i-1].val = i-13;
      cards[i-1].suit = "diamonds";
   }
   for(int i = 27; i < 40; i++) //hearts
   {
      cards[i-1].val = i-26;
      cards[i-1].suit = "hearts";
   }
   for(int i = 40; i < 53; i++) //spades
   {
      cards[i-1].val = i-39;
      cards[i-1].suit = "spades";
   }
   shuffle();    //cals the shuffle function made in deck to shuffle the new deck
}


/*********************************************************************
 ** Function: take_card 
 ** Description: returns the top card from the deck and lowers the number or cards
 ** Parameters: none
 ** Pre-Conditions: cards array is at least as big as num_cards
 ** Post-Conditions: num_cards is lowered by one
 **********************************************************************/
card deck::take_card()
{
   if(num_cards == 0)    // if the number of cards is zero, the deck needs to be reset
   {
      cout << "RESHUFFLING" << endl;
      shuffle();     //shuffles the cards again
      num_cards = 52;   //sets the number of cards back to 52
   }
   num_cards--;
   return cards[num_cards];    //decrement card numbers, and return the top card
}

/*********************************************************************
 ** Function:get_num_cards 
 ** Description: returns num_cards
 ** Parameters: 
 ** Pre-Conditions: 
 ** Post-Conditions: 
 **********************************************************************/
const int deck::get_num_cards() {return num_cards;}



