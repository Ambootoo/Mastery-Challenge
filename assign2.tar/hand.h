#include "./deck.h"
#pragma once

using namespace std;

class hand{
   card *cards;
   int num_cards;

   public:
      hand();
      ~hand();
      hand(hand &);
      bool is_ace() const;
      int get_ace_total() const;
      void operator =(const hand&);
      void set_num_cards(int num) {num_cards = num;}
      void delete_cards() {delete [] cards;}
      void print_hand() const;
      int get_card_total() const;
      int get_num_cards() const;
      void add_card(deck*);
      void set_first_cards(deck*);
      void dealer_print() const;
};
