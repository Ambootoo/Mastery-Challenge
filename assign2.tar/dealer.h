#include "./hand.h"
#pragma once

class dealer
{
   private:
      hand d_hand;

   public:
      int get_card_total() const;
      void add_card(deck*);
      void print_cards() const;
      void set_first_cards(deck*);
      void print_second_card() const;
      int get_ace_total() const;
};
