#include "./player.h"



/*********************************************************************
 ** Function: constructor 
 ** Description: sets the playing total to 500 anbd the bet to 0
 ** Parameters: none
 ** Pre-Conditions: none
 ** Post-Conditions: none
 **********************************************************************/
player::player()
{
   playing_total = 500;
   bet = 0;
}

/*********************************************************************
 ** Function: get_num_cards 
 ** Description: returns the number of cards
 ** Parameters: none
 ** Pre-Conditions: 
 ** Post-Conditions: 
 **********************************************************************/
int player::get_num_cards() const
{
   return p_hand.get_num_cards();
}

/*********************************************************************
 ** Function: set_first_cards 
 ** Description: calls hand set cards function
 ** Parameters: deck address
 ** Pre-Conditions: deck has been made 
 ** Post-Conditions: players hand has two cards
 **********************************************************************/
void player::set_first_cards(deck* d)
{
   p_hand.set_first_cards(d);
}

/*********************************************************************
 ** Function: get_ace_total 
 ** Description: calls hands get ace total
 ** Parameters: none
 ** Pre-Conditions: 
 ** Post-Conditions: 
 **********************************************************************/
int player::get_ace_total() const
{
   return p_hand.get_ace_total();
}

/*********************************************************************
 ** Function: is_ace 
 ** Description: tells whether the players hand has an ace or not
 ** Parameters: none
 ** Pre-Conditions: player has cards
 ** Post-Conditions: none
 **********************************************************************/
bool player::is_ace() const
{
   return p_hand.is_ace();
}

/*********************************************************************
 ** Function: get_card_total 
 ** Description: returns the hands get_card_total function
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
int player::get_card_total() const
{
   return p_hand.get_card_total();
}

/*********************************************************************
 ** Function: get_playing total 
 ** Description: returns the playing total
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
int player::get_playing_total() const
{
   return playing_total;
}

/*********************************************************************
 ** Function: add_bet 
 ** Description: adds current bet to the playing total
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
void player::add_bet()
{
   playing_total += bet;
}

/*********************************************************************
 ** Function: add_blackjack 
 ** Description: adds the players bet + half to the playing total
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
void player::add_blackjack()
{
   playing_total += (bet*1.5);
}

/*********************************************************************
 ** Function: take_bet 
 ** Description: takes current bet to the playing total
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
void player::take_bet()
{
   playing_total -= bet;
}

/*********************************************************************
 ** Function: set_bet 
 ** Description: gets the current bet
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: bet is set the input
 **********************************************************************/
void player::set_bet()
{
   int bet_test;
   cout << "How much do you want to bet?: ";
   cin >> bet_test;
   while(bet_test > playing_total)   //keep asking while they dont have enough
   {
      cout << "That bet is too high! Re-enter: ";
      cin >> bet_test;
   }
   bet = bet_test;
}

/*********************************************************************
 ** Function: add_card
 ** Description: adds a card to the hand
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
void player::add_card(deck* d)
{
   p_hand.add_card(d);
}

/*********************************************************************
 ** Function: print_cards 
 ** Description: prints cards
 ** Parameters: none
 ** Pre-Conditions: player has a hand
 ** Post-Conditions: none
 **********************************************************************/
void player::print_cards() const
{
   p_hand.print_hand();
}
