#pragma once
#include <iostream>
#include "player.h"

using namespace std;

class event
{
   public:
      virtual int do_event(player*, int, int)=0;
      virtual void print_message()=0;
};
