#include "room.h"
#include "wumpus.h"
#include "bat.h"
#include "pit.h"
#include "gold.h"
#include "player.h"
#include <stdlib.h>
#include <time.h>

/******************************************************
 * ** Program: HuntTheWumpus
 * ** Author: Josh Diedrich
 * ** Date: 05/23/2016
 * ** Description: hunt he wumpus
 * ******************************************************/ 


bool wumpus_life(room **r, int size)
{
   for(int i = 0; i < size; i++)
   {
      for(int j = 0; j < size; j++)    //runs through every room
      {
	 if(r[i][j].get_has_wumpus())    //if theres a wumpus return true
	    return true;
      }
   }
   return false;
}

/*********************************************************************
 * ** Function: fill_wumpus
 * ** Description: places the wumpus
 * ** Parameters: room ** r, size, locations array
 * ** Pre-Conditions: wumpus not placed
 * ** Post-Conditions: wumpus placed
 * *********************************************************************/
void fill_wumpus(room **r, int size, int* locations)
{
   wumpus *w = new wumpus;
   int x, y;
   for(int i = 0; i < 1; i++)
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)   //if there isnt already a wumpus
      {
	 r[x][y].set_event(w);
	 r[x][y].set_has_event(true);
	 r[x][y].set_has_wumpus(true);
	 locations[0] = x;
	 locations[1] = y;      //saving locations
      }
      else
	 i--;
   }
}

/*********************************************************************
 * ** Function: Fill_gold
 * ** Description: places the gold
 * ** Parameters: room r int size int locations
 * ** Pre-Conditions: gold not placed
 * ** Post-Conditions: gold placed
 * *********************************************************************/
void fill_gold(room **r, int size, int* locations)
{
   gold *g = new gold;
   int x, y;
   for(int i = 0; i < 1; i++)
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)   //if there isnt an event already
      {
	 r[x][y].set_event(g);
	 r[x][y].set_has_event(true);
	 r[x][y].set_has_gold(true);
	 locations[2] = x;
	 locations[3] = y;
      }
      else
	 i--;
   }
}

/*********************************************************************
 * ** Function: fill_bat
 * ** Description: places the bats
 * ** Parameters: room size
 * ** Pre-Conditions: bats not placed
 * ** Post-Conditions: bats placed
 * *********************************************************************/
void fill_bat(room **r, int size)
{
   bat *b1 = new bat;
   bat *b2 = new bat;
   int x, y;
   for(int i = 0; i < 1; i++)   //for 1 time
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)   //if there isnt an event
      {
	 r[x][y].set_event(b1);
	 r[x][y].set_has_event(true);   //set event to true
      }
      else
	 i--;   //otherwise restart
   }

   for(int i = 0; i < 1; i++)
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)
      {
	 r[x][y].set_event(b2);
	 r[x][y].set_has_event(true);
      }
      else
	 i--;
   }
   return;
}

/*********************************************************************
 * ** Function: fill_pit
 * ** Description: places pits
 * ** Parameters: room, size
 * ** Pre-Conditions: 
 * ** Post-Conditions:
 * *********************************************************************/
void fill_pit(room **r, int size)
{
   pit *b1 = new pit;
   pit *b2 = new pit;
   int x, y;
   for(int i = 0; i < 1; i++)   //for 1 time
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)   //if there isnt an event
      {
	 r[x][y].set_event(b1);
	 r[x][y].set_has_event(true);
      }
      else
	 i--;
   }

   for(int i = 0; i < 1; i++)
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)
      {
	 r[x][y].set_event(b2);
	 r[x][y].set_has_event(true);
      }
      else
	 i--;
   }
   return;
}

/*********************************************************************
 * ** Function: fill_player
 * ** Description: gives room the escape rope and player the coords
 * ** Parameters: room, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
player fill_player(room** r, int size)
{
   int x, y;
   player p(1,2);
   for(int i = 0; i < 1; i++)
   {
      x = rand() % size;
      y = rand() % size;
      if(r[x][y].get_has_event() == false)   //only put the player in an empty spot
      {
	 p.set_x(x);
	 p.set_y(y);
	 r[y][x].set_rope(true);   //put the rope where the player starts
      }
   }
   return p;
}

/*********************************************************************
 * ** Function: kill_wumpus
 * ** Description: kills the wumpus
 * ** Parameters: room, size
 * ** Pre-Conditions: wumpus is on board
 * ** Post-Conditions: wumpus is not on board
 * *********************************************************************/
void kill_wumpus(room **r, int size)
{
   for(int i = 0; i < size; i++)
   {
      for(int j = 0; j < size; j++)
      {
	 if(r[i][j].get_has_wumpus() == true)   //if the wumpus is there
	 {
	    r[i][j].set_has_wumpus(false);   //kill the wumpus
	    r[i][j].set_has_event(false);
	 }
      }
   }
}

/*********************************************************************
 * ** Function: kill_gold
 * ** Description: removes gold
 * ** Parameters: room, size
 * ** Pre-Conditions: gold is on board
 * ** Post-Conditions: gold is not on board
 * *********************************************************************/
void kill_gold(room **r, int size)
{
   for(int i = 0; i < size; i++)
   {
      for(int j = 0; j < size; j++)
      {
	 if(r[i][j].get_has_gold() == true)   //if there is gold
	 {
	    r[i][j].set_has_gold(false);   // remove it
	    r[i][j].set_has_event(false);
	 }
      }
   }
}

/*********************************************************************
 * ** Function: fire_right
 * ** Description: fires right
 * ** Parameters: player, room, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void fire_right(player *p, room **r, int size)
{
   int y = p->get_y();   //make a temporary y variable so u dont chane the real one
   int l[5];
   for(int i = 0; i < 3; i++)
   {
      y++;    //adding one to the y moves it to the right, grid is inverted
      if(y == size-1)
	 i = 3;
      if(r[p->get_x()][y].get_has_wumpus())   //if the wumpus is in the shotting range
      {
	 cout << "You killed the wumpus!!" << endl;
	 kill_wumpus(r, size);    //kill the wumpus
	 return;
      }
   }
   int random = rand() % 4;   //one in 4 chance
   if(random != 1)
   {
      cout << "The wumpus moved." << endl;
      kill_wumpus(r, size);
      fill_wumpus(r, size, l);   //kill and replace the wumpus
   }
}
/*********************************************************************
 * ** Function: fire left
 * ** Description: fires left
 * ** Parameters: player, rooom, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void fire_left(player *p, room **r, int size)
{
   int l[5];
   int y = p->get_y();
   for(int i = 0; i < 3; i++)
   {
      y--;
      if(y == 0)
	 i = 3;
      if(r[p->get_x()][y].get_has_wumpus())
      {
	 cout << "You killed the wumpus!!" << endl;
	 kill_wumpus(r, size);
	 return;
      }
   }
   int random = rand() % 4;
   if(random != 1)
   {
      cout << "The wumpus moved." << endl;
      kill_wumpus(r, size);
      fill_wumpus(r, size, l);
   }
}

void fire_up(player *p, room **r, int size)
{
   int l[5];
   int x = p->get_x();
   for(int i = 0; i < 3; i++)
   {
      x++;
      if(x == size-1)
	 i = 3;
      if(r[x][p->get_y()].get_has_wumpus())
      {
	 cout << "You killed the wumpus!!" << endl;
	 kill_wumpus(r, size);
	 return;
      }
   }
   int random = rand() % 4;
   if(random != 1)
   {
      cout << "The wumpus moved." << endl;
      kill_wumpus(r, size);
      fill_wumpus(r, size, l);
   }
}

void fire_down(player *p, room **r, int size)
{
   int l[5];
   int x = p->get_x();
   for(int i = 0; i < 3; i++)
   {
      x--;
      if(x == 0)
	 i = 3;
      if(r[x][p->get_y()].get_has_wumpus())
      {
	 cout << "You killed the wumpus!!" << endl;
	 kill_wumpus(r, size);
	 return;
      }
   }
   int random = rand() % 4;
   if(random != 1)
   {
      cout << "The wumpus moved." << endl;
      kill_wumpus(r, size);
      fill_wumpus(r, size, l);
   }
}
/*********************************************************************
 * ** Function: fire
 * ** Description: picks which way to shoot the arrow
 * ** Parameters: player, room, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void fire(player *p, room **r, int size)
{
   int choice;
   int outcome;
   int choosing = 1;
   while(choosing == 1)   //while they are still choosing
   {
      cout << "Right(1), Left(2), Up(3), Down(4): ";
      cin >> choice;
      if((choice == 1) && (p->get_y() < size -1))   //if the choice is 1 and they arent on the edge
      {
	 fire_right(p, r, size);
	 choosing = 0;
      }
      else if((choice == 2) && (p->get_y() > 0))   //if the choice is 2 and they arent on the edge
      {
	 fire_left(p, r, size);
	 choosing = 0;
      }
      else if((choice == 3) && (p->get_x() < size -1))  //and so on
      {
	 fire_up(p, r, size);
	 choosing = 0;
      }
      else if((choice == 4) && (p->get_x() > 0))
      {
	 fire_down(p, r, size);
	 choosing = 0;  //set choosing to 0 to leave loop
      }
      else
      {
	 cout << "You cant shoot that way" << endl;  //otherwise tell them they cant shoot that way and reprompt
      }
   }


}

/*********************************************************************
 * ** Function: move
 * ** Description: moves the player
 * ** Parameters: player, room, size
 * ** Pre-Conditions: player is at a position
 * ** Post-Conditions: player is at a different position
 * *********************************************************************/
void move(player *p, room **r, int size)
{
   int choosing = 1;
   int choice;
   while(choosing == 1)   //while they are still choosing
   {
      cout << "Right(1), Left(2), Up(3), Down(4): ";
      cin >> choice;
      if((choice == 1) && (p->get_y() < size-1))   //if choice is 1 and they arent on the edge
      {
	 p->set_y(p->get_y() + 1);
	 choosing = 0;   //lets them leave loop
      } 
      else if((choice == 2) && (p->get_y() > 0))  //if choice is 2 and they arent on the edge
      {
	 p->set_y(p->get_y() - 1);
	 choosing = 0;
      }
      else if((choice == 3) && (p->get_x() < size -1))  //and so on
      {
	 p->set_x(p->get_x() + 1);
	 choosing = 0;
      }
      else if((choice == 4) && (p->get_x() > 0))
      {
	 p->set_x(p->get_x() - 1);
	 choosing = 0;
      }
      else
      {
	 cout << "You cant move that way" << endl;
      }
   }
}

/*********************************************************************
 * ** Function: print_grid
 * ** Description: prints the grid
 * ** Parameters: player, room, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void print_grid(player *p, room **r,int size)
{
   for(int i = 0; i < size; i++)
   {
      for(int j = 0; j < size; j++)
      {
	 cout << "|";
	 if((j == p->get_y()) && (i == size - p->get_x()-1))   //grid goes (y, size-x)
	    cout << "X";
	 else
	    cout << "_";
	 cout << "|";
      }
      cout << endl;
   }
}

/*********************************************************************
 * ** Function: print_messages
 * ** Description: prints surrounding messages
 * ** Parameters: room, player, size
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void print_messages(room **r, player *p, int size)
{
   if((p->get_x() > 0) && (r[p->get_x()-1][p->get_y()].get_has_event()))
      r[p->get_x()-1][p->get_y()].print_message();
   if((p->get_x() < size-1) && (r[p->get_x()+1][p->get_y()].get_has_event()))
      r[p->get_x()+1][p->get_y()].print_message();
   if((p->get_y() < size-1) && (r[p->get_x()][p->get_y()+1].get_has_event()))  //if theres an event print the message
      r[p->get_x()][p->get_y()+1].print_message();
   if((p->get_y() > 0) && (r[p->get_x()][p->get_y()-1].get_has_event()))
      r[p->get_x()][p->get_y()-1].print_message();
}

/*********************************************************************
 * ** Function: print_menu
 * ** Description: prints the status of the wumpus and gold
 * ** Parameters: room, size, player
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void print_menu(room **r, int size, player *p)
{
   if(wumpus_life(r, size))   //if the wumpus is alive
      cout << endl << "Wumpus: alive." << endl;
   else
      cout << endl << "Wumpus: dead." << endl;
   if(p->get_has_gold())   //if the gold is found
      cout << "Gold: found." << endl << endl;
   else
      cout << "Gold: missing." << endl << endl;
}

/*********************************************************************
 * ** Function: play
 * ** Description: runs the loop to play the game
 * ** Parameters: room, size, player
 * ** Pre-Conditions: board is set up
 * ** Post-Conditions: game has been played
 * *********************************************************************/
void play(room **r, int size, player* p)
{

   int playing = 1;  //this keeps them playing
   int choice;
   int move_choice;
   int event_outcome = 0;   //this is what happens in the event, 1 is losing, 2 is bat, 3 is gold
   while(playing == 1)
   {
      print_grid(p, r, size);
      print_messages(r, p, size);
      cout << "X: " << p->get_y() << "  Y: " << p->get_x() << endl;
      cout << "Do you want to move(1), or shoot(2)?: ";
      cin >> choice;
      if(choice == 1)
      {
	 move(p, r, size); cout << endl;
	 if(r[p->get_x()][p->get_y()].get_has_event() == true)
	    event_outcome = r[p->get_x()][p->get_y()].do_event(p, size, size);
      }
      if(choice == 2)
      {
	 fire(p, r, size);
      }

      if(event_outcome == 1)  //outcome 1, losing
	 return;

      if(event_outcome == 2)   //outcome 2, bat
      {
	 if(r[p->get_x()][p->get_y()].get_has_event() == true)
	    event_outcome = r[p->get_x()][p->get_y()].do_event(p, size, size);
      }

      if(event_outcome == 3)   //outcome 3, gold
      {
	 kill_gold(r, size);
      }
      print_menu(r, size, p);
      if((!wumpus_life(r, size)) && (p->get_has_gold()) && (r[p->get_y()][p->get_x()].get_has_rope()))   //checks for win
      {
	 cout << "YOU WIN" << endl;
	 return;
      }

   }
}

/*********************************************************************
 * ** Function: place_wumpus_gold
 * ** Description: places the wumpus and gold if they arent there
 * ** Parameters: room, size, locations, player
 * ** Pre-Conditions:
 * ** Post-Conditions:
 * *********************************************************************/
void place_wumpus_gold(room **r, int size, int *locations, player *p)
{
	 wumpus *w = new wumpus;
	 gold *g = new gold;
	 if(!wumpus_life(r, size))
	 {
	    r[locations[0]][locations[1]].set_event(w);
	    r[locations[0]][locations[1]].set_has_wumpus(true);   //uses the saved location of wumpus from above
	    r[locations[0]][locations[1]].set_has_event(true);
	 }
	 else
	    delete w;
	 if(p->get_has_gold())
	 {
	    r[locations[2]][locations[3]].set_event(g);
	    r[locations[2]][locations[3]].set_has_gold(true);   //uses the saved location of gold from above
	    r[locations[2]][locations[3]].set_has_event(true);
	 }
	 else
	    delete g;
}


int main(int argc, char** argv)
{
   if(atoi(argv[1]) < 5)
      return 0;
   int size = atoi(argv[1]);
   int *locations = new int[4];   //these are the wumpus and golds locations
   int play_again = 1;
   srand(time(NULL));
   room **r;
   player p(2,2);
   while(play_again != 0)   //while they want to play again
   {
      if(play_again == 1)   //if they want a new board, refill the board
      {
	 r = new room*[size];
	 for(int i = 0; i < size; i++)
	    r[i] = new room[size];
	 fill_bat(r, size);
	 fill_pit(r, size);
	 fill_gold(r, size, locations);
	 fill_wumpus(r, size, locations);
      }
      p = fill_player(r, size);   //set the players location, then play
      cout << endl << endl << endl << endl;
      play(r, size, &p);
      cout << "Want to play again: New Board(1), Same Board(2): ";
      cin >> play_again;
      if(play_again == 1)   //if they want a new board, delete the old one
      {
	 for(int i = 0; i < size; i++)
	    delete [] r[i];
	 delete [] r;
      }
      if(play_again == 2)   //if they want the same board, place the gold and wumpus again
      {
	 place_wumpus_gold(r, size, locations, &p);
      }
   }

   for(int i = 0; i < size; i++)   //clearing memory
      delete [] r[i];
   delete [] r;
   delete [] locations;
}
