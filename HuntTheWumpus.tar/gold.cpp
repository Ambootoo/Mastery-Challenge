#include "gold.h"
#include "player.h"

void gold::print_message()
{
   cout << "You see a glimmer nearby" << endl;
}

int gold::do_event(player *p, int rows, int cols)
{
   cout << "You found the gold!" << endl;
   p->set_gold();
   return 3;
}
