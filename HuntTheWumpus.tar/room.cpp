#include "room.h"

void room::print_message()
{
   (*e).print_message();
}

int room::do_event(player *p, int rows, int cols)
{
   (*e).do_event(p, rows, cols);
}

void room::set_event(event *e1)
{
   if(e != NULL)
      delete e;
   e = e1;
}

room::~room()
{
   if(e != NULL)
   {
      delete e;
   }
}

room::room(const room &other)
{
   cout << "in the copy constructor" << endl;
   e = other.e;
}

room::room()
{
   e = NULL;
   has_rope = false;
   has_event = false;
   has_player = false;
   has_wumpus = false;
   has_gold = false;
}

void room::set_has_event(bool set)
{
   has_event = set;
}

void room::set_has_gold(bool set)
{
   has_gold = set;
}

void room::set_rope(bool set)
{
   has_rope = set;
}

void room::set_player(bool set)
{
   has_player = set;
}

bool room::get_has_player()
{
   return has_player;
}

bool room::get_has_rope()
{
   return has_rope;
}

bool room::get_has_event()
{
   return has_event;
}

void room::set_has_wumpus(bool set)
{
   has_wumpus = set;
}

bool room::get_has_wumpus()
{
   return has_wumpus;
}

bool room::get_has_gold()
{
   return has_gold;
}
