#pragma once
#include <iostream>
#include "wumpus.h"
#include "event.h"
#include "room.h"
#include "pit.h"
#include "bat.h"
#include "gold.h"

using namespace std;

class room
{
   private:
      bool has_gold;
      bool has_rope;
      bool has_event;
      bool has_player;
      bool has_wumpus;
      event *e;
   public:
      ~room();
      room();
      room(const room &other);
      void print_message();
      int do_event(player*, int, int);
      void set_event(event*);
      void set_rope(bool);
      void set_has_event(bool);
      void set_player(bool);
      void set_has_wumpus(bool);
      void set_has_gold(bool);
      bool get_has_rope();
      bool get_has_gold();
      bool get_has_event();
      bool get_has_player();
      bool get_has_wumpus();

      
};

