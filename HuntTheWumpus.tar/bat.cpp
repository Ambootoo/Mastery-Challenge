#include "bat.h"
#include <stdlib.h>


void bat::print_message()
{
   cout << "You hear wings flapping" << endl;
}

int bat::do_event(player *p, int rows, int cols)
{
   cout << "A bat moved you! "<< endl;
   (*p).set_x(rand() % cols);
   (*p).set_y(rand() % rows);
   return 2;
}
