#include "pit.h"

void pit::print_message()
{
   cout << "You feel a breeze" << endl;
}


int pit::do_event(player *p, int rows, int cols)
{
   cout << "You fell down a pit" << endl;
   return 1;
}
