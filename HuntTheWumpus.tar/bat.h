#pragma once
#include "room.h"
#include "event.h"
#include "player.h"
#include <iostream>


class bat: public event
{
   public:
      void print_message();
      int do_event(player *, int, int);
};
