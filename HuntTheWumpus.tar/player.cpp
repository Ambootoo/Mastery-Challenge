#include "player.h"

int player::get_x()
{
   return x;
}

int player::get_y()
{
   return y;
}

bool player::get_has_gold()
{
   return has_gold;
}

void player::set_x(int num)
{
   x = num;
}

void player::set_y(int num)
{
   y = num;
}

void player::set_gold()
{
   has_gold = true;
}

player::player(int x_cord, int y_cord)
{
   has_gold = false;
   x = x_cord;
   y = y_cord;
}
