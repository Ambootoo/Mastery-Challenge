#include "wumpus.h"

void wumpus::print_message()
{
   cout << "You smell a terrible stench" << endl;
}


int wumpus::do_event(player *p, int rows, int cols)
{
   cout << "You walked right into a wumpus! He ate you." << endl;
   return 1;
}
