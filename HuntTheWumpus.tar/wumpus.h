#pragma once
#include "room.h"
#include "event.h"
#include <iostream>

class wumpus: public event
{
   public:
      void print_message();
      int do_event(player *, int, int);
};
