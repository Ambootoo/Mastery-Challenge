#pragma once
#include <iostream>

using namespace std;

class player
{
   private:
      int x;
      int y;
      bool has_gold;
   public:
      void set_x(int);
      void set_y(int);
      void set_gold();
      bool get_has_gold();
      int get_x();
      int get_y();
      player(int, int);
};
